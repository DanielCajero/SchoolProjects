/*Age Calculator Exercise
1. Ask user for their Age
2. Calculate the total amount of days based of the age
3. Display the user roughly how many days they've been alive
*/

var age = prompt('How old are you?');

var days = age * 365;

output.innerHTML = 'You have been around for about ' + days;

/*
var line = document.getElementById(output);
var line2 = document.getElementById(outputname);

console.log(line);
console.log(line2);
//console.log(output);
*/
